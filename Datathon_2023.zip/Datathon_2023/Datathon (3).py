import psycopg

conn = psycopg.connect(dbname="postgres", user="postgres", password="DatathonDog$", host="localhost", port=5432)

cur = conn.cursor()
cur.execute("SELECT * FROM ENROLL")

print(cur.fetchall())
